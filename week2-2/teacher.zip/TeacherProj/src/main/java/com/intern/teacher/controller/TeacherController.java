package com.intern.teacher.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.intern.teacher.entity.Teacher;
import com.intern.teacher.service.TeacherService;

@RestController 
public class TeacherController {
	
	@Autowired
	TeacherService teacherService;
      
	@GetMapping(value ="/teacher")
	public List<Teacher> getAllTeacher() {
		  List<Teacher> teacherList=teacherService.findAll();
		  return teacherList;
	}
	@PostMapping (value="/teacher")
	public Teacher createTeacher(@RequestBody Teacher teacher) {
		return teacherService.createTeacher(teacher);
	}
	
	@GetMapping(value="/teacher/{id}")
	public Teacher getTeacherById(@PathVariable Long id) {
		return teacherService.getTeacherById(id);
	}
	
	@DeleteMapping("/teacher/{id}")
	public void deleteTeacherById(@PathVariable Long id) {
		teacherService.deleteTeachertById(id);
	}
}

