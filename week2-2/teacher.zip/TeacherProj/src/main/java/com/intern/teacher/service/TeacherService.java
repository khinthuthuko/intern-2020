package com.intern.teacher.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.intern.teacher.entity.Teacher;
import com.intern.teacher.repository.TeacherRepository;

@Service
public class TeacherService {
	@Autowired
	TeacherRepository teacherRepository;
	
	public List<Teacher> findAll(){
		List<Teacher> teacherList=teacherRepository.findAll();
		return teacherList;
	}
	
	public Teacher createTeacher(Teacher teacher) {
		return teacherRepository.save(teacher);
	}
	
	public Teacher getTeacherById(Long id) {
		return teacherRepository.findById(id).orElse(null);
	}
	
	public void deleteTeachertById(Long id) {
		teacherRepository.deleteById(id);
	}
     
}
