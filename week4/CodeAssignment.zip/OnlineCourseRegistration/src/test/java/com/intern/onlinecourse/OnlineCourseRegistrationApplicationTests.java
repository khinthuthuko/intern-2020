package com.intern.onlinecourse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineCourseRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
