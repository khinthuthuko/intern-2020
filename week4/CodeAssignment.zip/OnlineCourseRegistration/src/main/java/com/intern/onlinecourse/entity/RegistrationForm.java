package com.intern.onlinecourse.entity;


import java.util.*;

public class RegistrationForm {

   
    public RegistrationForm() {
    }

    
    private String Registration_id;
    private String Registration_Student_Id;
    private Date Registration_date;
    private String Registration_Number;
   


    public String getRegistration_id() {
		return Registration_id;
	}



	public void setRegistration_id(String registration_id) {
		Registration_id = registration_id;
	}



	public String getRegistration_Student_Id() {
		return Registration_Student_Id;
	}



	public void setRegistration_Student_Id(String registration_Student_Id) {
		Registration_Student_Id = registration_Student_Id;
	}



	public Date getRegistration_date() {
		return Registration_date;
	}



	public void setRegistration_date(Date registration_date) {
		Registration_date = registration_date;
	}



	public String getRegistration_Number() {
		return Registration_Number;
	}



	public void setRegistration_Number(String registration_Number) {
		Registration_Number = registration_Number;
	}



	 

}