package com.intern.onlinecourse.entity;


import java.util.*;

public class Administrator {

   public Administrator() {
	   
   }
    private String Admin_id;
    private String Admin_Name;
    private String Admin_phone;


    public String getAdmin_id() {
		return Admin_id;
	}


	public void setAdmin_id(String admin_id) {
		Admin_id = admin_id;
	}


	public String getAdmin_Name() {
		return Admin_Name;
	}


	public void setAdmin_Name(String admin_Name) {
		Admin_Name = admin_Name;
	}


	public String getAdmin_phone() {
		return Admin_phone;
	}
     


	public void setAdmin_phone(String admin_phone) {
		Admin_phone = admin_phone;
	}


	 

}