package com.intern.onlinecourse.service;

import com.intern.onlinecourse.entity.Administrator;

public class serviceAdministrator {
    
	public void canView(Administrator administrator) {
    
    }
    public void canConfirm(Administrator administrator) {
       
    }
}
