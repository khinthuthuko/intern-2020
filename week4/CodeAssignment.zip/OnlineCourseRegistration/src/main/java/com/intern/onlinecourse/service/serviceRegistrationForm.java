package com.intern.onlinecourse.service;

import com.intern.onlinecourse.entity.RegistrationForm;

public class serviceRegistrationForm {

	public void canSubmit(RegistrationForm registration) {
        
    }
}
