package com.intern.onlinecourse.entity;
public class Student {

    public Student() {
    }

 
    private String Student_Id;
    private String Student_Name;
    private String Major;
    private String Gender;
    private String Email;
    private String Address;
    private String Phone;
    
    public String getStudent_Id() {
		return Student_Id;
	}

	public void setStudent_Id(String student_Id) {
		Student_Id = student_Id;
	}

	public String getStudent_Name() {
		return Student_Name;
	}

	public void setStudent_Name(String student_Name) {
		Student_Name = student_Name;
	}

	public String getMajor() {
		return Major;
	}

	public void setMajor(String major) {
		Major = major;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getPhone() {
		return Phone;
	}

	public void setPhone(String phone) {
		Phone = phone;
	}

	 

}