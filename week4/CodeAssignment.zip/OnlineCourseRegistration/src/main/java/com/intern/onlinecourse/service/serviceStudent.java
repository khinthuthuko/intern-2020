package com.intern.onlinecourse.service;

import com.intern.onlinecourse.entity.Student;

public class serviceStudent {
  
	public void canRegister(Student student) {
      
    }


    public void canLogin(Student student) {
     
    }
}
