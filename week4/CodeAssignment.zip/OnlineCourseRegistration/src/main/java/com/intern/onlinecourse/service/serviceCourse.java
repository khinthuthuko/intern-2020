package com.intern.onlinecourse.service;

import com.intern.onlinecourse.entity.Course;

public class serviceCourse {

	public void addCourse(Course course) {
      
    }

  
    public void deleteCourse(Course course) {
    
    }

    public void acceptCourseRegistration(Course course) {
    
    }
}
