package com.intern.onlinecourse.entity;

public class Department {

    
    public String Department_Id;
    public String Department_Name;
    public String Description;
	public String getDepartment_Id() {
		return Department_Id;
	}
	public void setDepartment_Id(String department_Id) {
		Department_Id = department_Id;
	}
	public String getDepartment_Name() {
		return Department_Name;
	}
	public void setDepartment_Name(String department_Name) {
		Department_Name = department_Name;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}



}