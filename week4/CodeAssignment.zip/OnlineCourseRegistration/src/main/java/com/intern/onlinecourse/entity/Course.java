package com.intern.onlinecourse.entity;


import java.util.*;

public class Course {

  
    public Course() {
    }
    private String Course_Id;
    private String Course_Name;
    private String Course_year;
    
    
    public String getCourse_Id() {
		return Course_Id;
	}


	public void setCourse_Id(String course_Id) {
		Course_Id = course_Id;
	}


	public String getCourse_Name() {
		return Course_Name;
	}


	public void setCourse_Name(String course_Name) {
		Course_Name = course_Name;
	}


	public String getCourse_year() {
		return Course_year;
	}


	public void setCourse_year(String course_year) {
		Course_year = course_year;
	}


	 

}