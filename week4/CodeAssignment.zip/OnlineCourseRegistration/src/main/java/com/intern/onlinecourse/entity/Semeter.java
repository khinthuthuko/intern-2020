package com.intern.onlinecourse.entity;


import java.util.*;

public class Semeter {

   
    public Semeter() {
    }

    private String Semeter_id;
    private Date SemeterStartDate;
    private Date SemeterEndDate;
	public String getSemeter_id() {
		return Semeter_id;
	}
	public void setSemeter_id(String semeter_id) {
		Semeter_id = semeter_id;
	}
	public Date getSemeterStartDate() {
		return SemeterStartDate;
	}
	public void setSemeterStartDate(Date semeterStartDate) {
		SemeterStartDate = semeterStartDate;
	}
	public Date getSemeterEndDate() {
		return SemeterEndDate;
	}
	public void setSemeterEndDate(Date semeterEndDate) {
		SemeterEndDate = semeterEndDate;
	}
	 




}