package com.intern.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="PERSON")
@SequenceGenerator(name="seq",initialValue=1,allocationSize=100)
public class Person {
    
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	private int id;
	@Column(name="PERSON_NAME")
	private String name;
	@Column(name="PERSON_PHONE")
	private String phone;
	@ManyToOne(optional=false)
	@JoinColumn(name="HOME_Id")
	private Home home;
	
   
	public Home getHome() {
		return home;
	}
	public void setHome(Home home) {
		this.home = home;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	
}
