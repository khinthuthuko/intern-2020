package com.intern.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.intern.demo.entity.Home;
import com.intern.demo.service.HomeService;

@RestController
public class HomeController {
 
	@Autowired
	HomeService homeService;
	
	@GetMapping(value= "/home")
	public List<Home> getHome(){
		return homeService.getHome();
	}
	
	@PostMapping(value= "/home")
	public Home add(@RequestBody Home home) {
		return homeService.addHome(home);
	}
	 
	@GetMapping(value="/home/{id}")
	public Home getHomeById(@PathVariable int id) {
		return homeService.getHomeById(id);
	}
	
	@DeleteMapping(value="/home")
		public void deleteHomeById(@PathVariable int id) {
		 homeService.deleteHome(id);
	}
	 
    
}
