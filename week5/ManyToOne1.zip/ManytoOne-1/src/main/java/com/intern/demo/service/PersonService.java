package com.intern.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.intern.demo.entity.Person;
import com.intern.demo.repository.PersonRepository;

@Service
public class PersonService {
  
	@Autowired
	PersonRepository personRepository;
	
	public List<Person> getPerson(){
		return personRepository.findAll();
	}
	
	public Person addPerson(Person person){
		return personRepository.save(person);
	}
	
	public Person getPersonById(int id) {
		return personRepository.findById(id).orElse(null);
	}
	
	public void deletePersonById(int id) {
		personRepository.deleteById(id);
	}
	
}
