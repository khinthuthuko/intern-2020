package com.intern.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.intern.demo.entity.Home;

public interface HomeRepository extends JpaRepository<Home,Integer>{

}
