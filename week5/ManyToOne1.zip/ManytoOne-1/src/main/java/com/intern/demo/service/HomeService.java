package com.intern.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.intern.demo.entity.Home;
import com.intern.demo.repository.HomeRepository;

@Service
public class HomeService {

	@Autowired
	HomeRepository homeRepository;
	
	public List<Home> getHome(){
		return homeRepository.findAll();
	}
	
	public Home addHome(Home home){
		return homeRepository.save(home);
	}
	
	public Home getHomeById(int id) {
		return homeRepository.findById(id).orElse(null);
	}
	
	 
	public void deleteHome(int id) {
		homeRepository.deleteById(id);
	}

	
	
}
