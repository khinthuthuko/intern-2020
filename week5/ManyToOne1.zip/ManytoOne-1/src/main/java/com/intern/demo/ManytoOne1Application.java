package com.intern.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManytoOne1Application {

	public static void main(String[] args) {
		SpringApplication.run(ManytoOne1Application.class, args);
	}

}
