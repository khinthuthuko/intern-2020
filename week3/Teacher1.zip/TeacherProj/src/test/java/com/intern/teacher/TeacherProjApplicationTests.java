package com.intern.teacher;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeacherProjApplicationTests {

	@Test
	void contextLoads() {
	}

}
