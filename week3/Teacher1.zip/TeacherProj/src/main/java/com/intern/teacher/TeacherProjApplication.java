package com.intern.teacher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeacherProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeacherProjApplication.class, args);
	}

}
