package com.intern.teacher.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TEACHER")
@SequenceGenerator(name="seq",initialValue=1,allocationSize=100)
public class Teacher {
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
    long id;
    
    @Column(name="TEACHER_NAME")
    String teachername;
    
    @Column(name="TEACHER_DEPARTMENT")
    String teacherdepartment;
    
    @Column(name="TEACHER_PHONE")
    String teacherphone;
    
    @Column(name="TEACHER_ADDRESS")
    String teacheraddress;
    
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTeachername() {
		return teachername;
	}

	public void setTeachername(String teachername) {
		this.teachername = teachername;
	}

	public String getTeacherdepartment() {
		return teacherdepartment;
	}

	public void setTeacherdepartment(String teacherdepartment) {
		this.teacherdepartment = teacherdepartment;
	}

	public String getTeacherphone() {
		return teacherphone;
	}
    public String getTeacheraddress() {
			return teacheraddress;
    }

    public void setTeacheraddress(String teacheraddress) {
			this.teacheraddress = teacheraddress;
		}

	public void setTeacherphone(String teacherphone) {
		this.teacherphone = teacherphone;
	}
    
}
