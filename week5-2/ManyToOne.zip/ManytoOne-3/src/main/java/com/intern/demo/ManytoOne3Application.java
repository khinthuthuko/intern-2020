package com.intern.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManytoOne3Application {

	public static void main(String[] args) {
		SpringApplication.run(ManytoOne3Application.class, args);
	}

}
